// No background logic is needed, but the file must exist otherwise chrome throws error
